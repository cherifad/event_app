import 'package:event_poll/states/polls_state.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../states/auth_state.dart';
import 'package:provider/provider.dart';

class PollsPage extends StatefulWidget {
  const PollsPage({super.key, required Center child});

  @override
  State<PollsPage> createState() => _PollsPageState();
}

class _PollsPageState extends State<PollsPage> {
  @override
  Widget build(BuildContext context) {
    context.read<PollsState>().fetchPolls();
    final polls = context.watch<PollsState>().polls;
    final mq = MediaQuery.of(context);
    return ListView.builder(
      itemCount: polls.length,
      itemBuilder: (context, index) {
        final poll = polls[index];
        return Padding(
          padding: EdgeInsets.symmetric(
              horizontal: mq.size.width * 0.05,
              vertical: mq.size.height * 0.01),
          child: Card(
            child: Column(
              children: [
                ListTile(
                  title: Text(poll.name),
                  subtitle: Text(poll.description),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    context.read<AuthState>().isLoggedIn == true
                        ? TextButton(
                            onPressed: () {
                              Navigator.pushNamed(context, '/polls/${poll.id}');
                            },
                            child: const Text('Je participe'),
                          )
                        : const SizedBox.shrink(),
                    const SizedBox(width: 8),
                    context.read<AuthState>().currentUser?.isAdmin == true
                        ? Row(children: [
                            TextButton(
                              onPressed: () {
                                Navigator.pushNamed(
                                    context, '/polls/${poll.id}/edit');
                              },
                              child: const Text('Modifier'),
                            ),
                            const SizedBox(width: 8),
                            TextButton(
                              onPressed: () {
                                // context.read<PollsState>().deletePoll(poll.id);
                              },
                              child: const Text('Supprimer'),
                            ),
                          ])
                        : const SizedBox.shrink(),
                    const SizedBox(width: 8),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
