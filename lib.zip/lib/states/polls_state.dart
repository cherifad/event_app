import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';

import '../configs.dart';
import '../models/poll.dart';
import '../models/user.dart';
import 'package:http/http.dart' as http;

class PollsState extends ChangeNotifier {

  String? _token;

  List<Poll> _polls = [];
  List<Poll> get polls => _polls;

  void setToken(String? token) {
    _token = token;
  }

  Future<void> fetchPolls() async {
    final response = await http.get(
      Uri.parse('${Configs.baseUrl}/polls'),
      headers: {
        HttpHeaders.contentTypeHeader: 'application/json',
      },
    );
    if (response.statusCode == HttpStatus.ok) {
      _polls = (json.decode(response.body) as List)
          .map((e) => Poll.fromJson(e))
          .toList();
      notifyListeners();
    }
  }
}
